@echo off
@rem 文字コードをUTF-8に変換
chcp 65001

@rem Javaのインストール確認
java -version >nul 2>&1
if %errorlevel% neq 0 (
    echo エラー：Javaがインストールされていません。
    echo Java 11以上をインストールしてください。
    echo https://adoptium.net/
    pause
    exit /b
)

@rem このbatファイルがある場所を基準にする（どこに置いても動く）
set BASE_DIR=%~dp0

@rem outputフォルダの中身を確認・削除
echo ========================================
set /p CONFIRM= ▼ output フォルダ内のファイルを全て削除します。よろしいですか？ (Y/N): 
echo ========================================

if /i not "%CONFIRM%"=="Y" (
    echo 処理をキャンセルしました。
    pause
    exit /b
)
del /q "%BASE_DIR%output\"
echo 削除完了。処理を開始します。
echo.

@rem jarファイル実行（BASE_DIRを引数として渡す）
cmd /k java -Dfile.encoding=UTF-8 -jar "%BASE_DIR%jar\columnDivide.jar" "%BASE_DIR%"