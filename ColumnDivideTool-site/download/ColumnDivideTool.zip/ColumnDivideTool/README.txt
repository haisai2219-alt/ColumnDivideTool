# ColumnDivideTool

## 概要
CSVファイルを指定したカラムの値ごとにファイル分割するツールです。

## 動作環境
- OS: Windows 10 / 11
- Java: 11以上（インストール済みであること）

## フォルダ構成
ColumnDivideTool/
├── columnDivide.bat   # 実行ファイル
├── config.txt         # 設定ファイル
├── input/             # 分割したいCSVをここに格納
├── output/            # 分割されたCSVがここに出力される
└── jar/               # ※触らない

## 使い方
1. input/ フォルダに分割したいCSVファイルを置く
2. config.txt を開いて設定を行う
3. columnDivide.bat をダブルクリックして実行する
4. output/ フォルダに結果が出力される

## 設定項目（config.txt）
・targetColumnName：分割基準にするカラム名（必須） [例： COMPANYCODE]
・maxRecordsPerFile：1ファイルの最大行数（空欄で無制限） [例： 1000 ]
・exactMatchValue：完全一致フィルタ（空欄で無効） [例： COMP001 ]
・partialMatchValue：部分一致フィルタ（空欄で無効） [例： COMP ]
・includeHeader：ヘッダー行を出力するか [例： true / false ]
・originalName：出力ファイル名に元ファイル名を付けるか [例： true / false ]

## 注意事項
- 実行するたびにoutput/フォルダの中身は全削除されます
- 入力CSVはUTF-8形式のみ対応しています
- カラム名は大文字・小文字を区別します
- 空のデータは「00__EMPTY」として出力されます